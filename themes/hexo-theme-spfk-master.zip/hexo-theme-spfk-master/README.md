![luuman-ipad-iphone](https://hexo.io/build/screenshots/spfk-025d1cd820.png)

　　** SPFK Hexo 主题：**用了yilia主题一段时间，感觉还有很多可以提高的地方，就查阅资料，对其进行粗类的修改，但是，有其实还有很多不完善的地方，欢迎大家前捧场。
没想到，这么多人喜欢黑色版本的，建议不是每个人都喜欢我的这些功能，所以准备个基础版本，插件可以看教程自行安装。


注意：使用本主题请仔细查看[Hexo 主题：SPFK](http://luuman.github.io/categories/Hexo/)，

没有使用过Hexo的同学可以看看[GitHub Hexo搭建](http://luuman.github.io/categories/Hexo/)，另外还有一个我自己搭建时，插件的安装教程[Hexo插件安装](http://luuman.github.io/categories/Hexo/)


正如前辈们所说，我们使用博客的目的是分享经验，总结自己，督促自己不断提升。如果你有不喜欢，不断的改进吧。只要你玩的开心！（请不要再这浪费太多精力，去丰富你的博客内容吧，骚年！）

声明：由于博主一直使用，关于Blog仓库，需要设置_config.yml

```
## If your site is put in a subdirectory, set url as 'http://luuman.github.io/child' and root as '/child/'
url: http://luuman.github.io/Blog
root: /Blog/
# url: http://luuman.github.io
# root: /
```

## 作品展示
关于作品展示页面，直接去看看[hexo仓库](https://github.com/luuman/Hexo)，将必要的页面放置进去即可，样式主题已经配置。里面只要配置些图片，链接即可！


